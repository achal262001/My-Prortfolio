import React from "react";

function GetOTP({ length = 4, onOTPSumbit = () => {} }) {
  return (
    <div>
      <div>Enter OTP sent to </div>
    </div>
  );
}

export default GetOTP;
