export interface Note{
    id:number;
    name:string;
    notes:string;
    color:string;
    completed:boolean;
}
// export interface Note1{
//     noteId:number;
//     description:string;
//     // completed:boolean;
// }

// export interface Notes1 {
//     id:number;
//     note:Note1;
//     color:string;
// }