const name = function () {
  console.log("MY NAME IS ACHAL KOKATANOOR");
};

export { name };
