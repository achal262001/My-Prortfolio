let item = document.querySelector("#item");
const toDoBox = document.querySelector("#to-do-list");

item.addEventListener("Keyup", function (event) {
  console.log(event);
});

console.log("a");
