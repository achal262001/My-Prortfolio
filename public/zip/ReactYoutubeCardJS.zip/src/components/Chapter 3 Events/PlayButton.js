import { useState } from "react";

function PlayButton({ children, onPlay, onPause }) {
  let [status, useStatus] = useState(false);
  function Handel() {
    if (!status) {
      onPlay();
    } else {
      onPause();
    }
    useStatus(!status);
  }
  return (
    <>
      <button onClick={Handel} style={{ borderRadius: 19 }}>
        {children} :{status ? "⏸️" : "▶️"}
      </button>
    </>
  );
}
export default PlayButton;
