import { useEffect, useState } from "react";

const initialState = {
  time: "",
  channel: "",
  verified: false,
  title: "",
  views: "",
};
function AddVideo({ addVideo, editAVideo }) {
  const [video, setVideo] = useState(initialState);

  function handleSubmit(e) {
    e.preventDefault();
    addVideo(video);
  }

  function handleChange(e) {
    setVideo({ ...video, [e.target.name]: e.target.value });
  }

  useEffect(() => {
    if (editAVideo) {
      setVideo(editAVideo);
      console.log(editAVideo);
    }
  }, [editAVideo]);

  return (
    <>
      <form>
        <div>
          <label htmlFor="title">Video Title</label>
          <input
            onChange={handleChange}
            type="text"
            name="title"
            placeholder="Video Title"
            value={video.title}
          ></input>
        </div>
        <div>
          <label>Channel Name</label>
          <input
            onChange={handleChange}
            type="text"
            name="channel"
            placeholder="Channel Name"
            value={video.channel}
          ></input>
        </div>
        <div>
          <label>Video views</label>
          <input
            onChange={handleChange}
            type="text"
            name="views"
            value={video.views}
            placeholder="Video views"
          ></input>
        </div>
        <div>
          <label>How old this video is</label>
          <input
            onChange={handleChange}
            type="text"
            name="time"
            value={video.time}
            placeholder="How old this video is"
          ></input>
        </div>
        <button onClick={handleSubmit}>AddVideo</button>
      </form>
    </>
  );
}

export default AddVideo;
