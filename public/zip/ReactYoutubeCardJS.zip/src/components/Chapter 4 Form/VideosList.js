import PlayButton from "../Chapter 3 Events/PlayButton";
import Videos from "../Chapter 2 function/Videos";
function VideosList({ videos, deleteVideo, editVideo }) {
  {
    return (
      <>
        {videos.map((v) => (
          <Videos
            key={v.id}
            id={v.id}
            title={v.title}
            views={v.views}
            time={v.time}
            channel={v.channel}
            verified={v.verified}
            deleteVideo={deleteVideo}
            editVideo={editVideo}
          >
            <PlayButton
              onPlay={() => console.log("Play...!", v.title)}
              onPause={() => console.log("Pause...!", v.title)}
            >
              {v.title}
            </PlayButton>
          </Videos>
        ))}
      </>
    );
  }
}
export default VideosList;
