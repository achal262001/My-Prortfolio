import React, { useReducer } from "react";

const initialVal = 0;
const reducer = (useS, action) => {
  switch (action) {
    case "Increment":
      return useS + 1;
    case "Decrement":
      return useS - 1;
    case "Reset":
      return initialVal;
    default:
      return useS;
  }
};

function UseReducer() {
  let [count, dispatch] = useReducer(reducer, initialVal);
  return (
    <div>
      <div>{count}</div>
      <button onClick={() => dispatch("Increment")}>Increment</button>
      <button onClick={() => dispatch("Decrement")}>Decrement</button>
      <button onClick={() => dispatch("Reset")}>Reset</button>
    </div>
  );
}
export default UseReducer;
