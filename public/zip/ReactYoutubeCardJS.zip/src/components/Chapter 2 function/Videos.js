import "./Video.css";
function Videos({
  title,
  channel,
  id,
  children,
  verified,
  deleteVideo,
  editVideo,
  views,
  time,
}) {
  return (
    <>
      <div className="container">
        <button className="deleteVideo" onClick={() => deleteVideo(id)}>
          X
        </button>
        <button className="editVideo" onClick={() => editVideo(id)}>
          edit
        </button>
        <div className="pic">
          <img src={`https://picsum.photos/id/${id}/160/90`}></img>
        </div>
        <div className="title">
          <h5>{title}</h5>
        </div>
        <div className="channel">
          <div>
            {channel} {verified ? "✅" : null}
          </div>
        </div>
        <div>
          {views}
          <span>.</span> {time}
        </div>
        {children}
      </div>
    </>
  );
}
export default Videos;
