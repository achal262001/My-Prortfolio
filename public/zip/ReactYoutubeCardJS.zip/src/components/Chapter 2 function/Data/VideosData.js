let Videos = [
  {
    id: 1,
    title: "black doggy",
    views: "100k Views",
    time: "8 months ago",
    channel: "Coder Dosth",
    verified: true,
  },
  {
    id: 2,
    title: "Kari Nayyi",
    views: "1M Views",
    time: "10 months ago",
    channel: "Coder Dosth",
    verified: true,
  },
  {
    id: 3,
    title: "Kari Mani Malikan Nayi",
    views: "189k Views",
    time: "10 year ago",
    channel: "Coder Dosth",
    verified: false,
  },
];

export default Videos;
