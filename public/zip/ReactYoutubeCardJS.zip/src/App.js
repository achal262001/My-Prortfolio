import UseState from "./components/useState.js";
import { useState } from "react";
import UseReducer from "./components/useReducer.js";
import React from "react";
import VideosData from "./components/Chapter 2 function/Data/VideosData.js";
import "./App.css";
import AddVideo from "./components/Chapter 4 Form/AddVideo.js";
import VideosList from "./components/Chapter 4 Form/VideosList.js";

function App() {
  let [videos, setVideos] = useState(VideosData);
  const [editAVideo, setEditAVideo] = useState(null);

  function addVideo(Vid) {
    setVideos([...videos, { ...Vid, id: videos.length + 1 }]);
  }
  function deleteVideo(id) {
    setVideos(videos.filter((Vi) => Vi.id !== id));
  }
  function EditVideo(id) {
    setEditAVideo([videos.find((vi) => vi.id === id)]);
  }
  return (
    <>
      <AddVideo addVideo={addVideo} editAVideo={editAVideo}></AddVideo>
      <VideosList
        deleteVideo={deleteVideo}
        editVideo={EditVideo}
        videos={videos}
      ></VideosList>
    </>
  );
}
export default App;
